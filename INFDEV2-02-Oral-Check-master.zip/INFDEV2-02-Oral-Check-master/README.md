Oral check INFDEV02-2
=====================

Regels
------

- Dit is een toetsmoment, dus het examenreglement is van toepassing
- tijdens de toets is geen enkel andere applicatie gestart dan de IDE waarmee je werkt (als een van de docenten/surveillanten constateert dat een applicatie is opgestart die niet is toegestaan kan dit leiden tot een vermoeden van fraude);
- de taakbalk is te allen tijde zichtbaar onder in het scherm.


Opdracht
--------

- Download deze opdracht door:
  - het project met de git-integratie van je IDE automatisch te downloaden of,
  - via je browser "download zip" te klikken, de zip uit te pakken en de map te openen in je IDE. 
- Zorg dat de functionaliteit van de 3 assignments hersteld wordt. Dat doe je door onder elke aangegeven plek in de code een regel code toe te voegen. De plek is aangegeven met het volgende commentaar:
        #TODO INSERT MISSING LINE BELOW
  Laat bovenstaande commentaar-regel staan en voeg jouw code daaronder toe!
    Tip: voor een overzichtsscherm van alle TODO's:
     - in PyCharm: druk op ALT+6 (of CMD+6 mac) 
     - in visual studio : druk op CRTL+\, t  
 - Als je klaar bent met de assignments, steek dan je hand op. De surveillerende docent komt bij je om je werk te controleren. 
